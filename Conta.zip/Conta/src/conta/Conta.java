/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conta;

public class Conta {

    public String numeroAgencia;
    public String numeroConta;
    public double saldo;

    public static void depositar(Conta c1, double valor) {
        if (valor > 0 && c1 != null) {
            c1.saldo += valor;
            System.out.println("Depósito realizado!");
            System.out.println("novo saldo " + c1.saldo);

        }
    }
    public static void ralizarEmprestimo(double valor, double renda, Conta c1) {
        if(valor>0&& (renda >=998&& renda <= 2000)){
            System.out.println("Emprestimo até:"+5000);
            System.out.println("Emprestimo Realizado!");
            c1.saldo=5000;
            
        }
        
    }

    public void realizarSaque(double valor) {
        if (valor <= 0 || valor > saldo) {
            System.out.println("Saque não realizado!");
        } else {
            this.saldo -= valor;
            System.out.println("Saque Realizado");
            System.out.println("Novo saldo:" + this.saldo);
        }
    }

    public void transferir(Conta contaDestino, double valor) {
        if (this.saldo >= valor && contaDestino != null) {
            contaDestino.saldo += valor;
            this.saldo -= valor;
            System.out.println("Transferencia relizada");
            System.out.println("Novo saldo " + this.saldo);
            System.out.println("Novo saldo C.destino " + contaDestino.saldo);
        }

    }
}
