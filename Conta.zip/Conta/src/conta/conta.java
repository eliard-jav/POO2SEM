/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conta;


public class conta {
    public String numeroAgencia;
    public String numeroConta;
    public double saldo;
    
    public static void depositar(conta c1, double valor){
       if(valor > 0 &&c1!=null) {
           c1.saldo += valor;
           System.out.println("Depósito realizado!");
           System.out.println("novo saldo "+c1.saldo);
           
       }
    }
   public void transferir(conta contaDestino, double valor){
         if(this.saldo >= valor && contaDestino != null){
           contaDestino.saldo += valor;
           this.saldo-=valor;
             System.out.println("Transferencia relizada");
             System.out.println("Novo saldo "+this.saldo);
             System.out.println("Novo saldo C.destino "+contaDestino.saldo);
       }
       
   } 
}
