/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import conta.Conta;


public class Main {
    public static void main(String[] args) {
       //Instancia a conta!!!
        Conta c1 = new Conta();
        Conta c2 = new Conta();
        
        Conta.depositar(c1, 500);
        
        c1.realizarSaque(200);
        
        Conta.ralizarEmprestimo(5000, 1500, c2);
        
        
    }
}
