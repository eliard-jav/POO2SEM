/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import conta.conta;

/**
 *
 * @author LABORATORIO 01
 */
public class Main {
    public static void main(String[] args) {
        conta c1 = new conta();
        conta c2 = new conta();
        
        c1.numeroAgencia= "123-2";
        c1.numeroConta="123-2";
        
        c2.numeroAgencia="321-2";
        c2.numeroConta="321-2";
        
        c1.depositar(c2,200);
        
        c2.transferir(c1, 150);
        
        
        
        
    }
}
