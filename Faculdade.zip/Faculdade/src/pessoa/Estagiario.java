/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pessoa;

/**
 *
 * @author LABORATORIO 01
 */
public class Estagiario extends Funcionario{
    private String DatEncerramento;
    private String DatInicio;
    private String Cargoraria;

    /**
     * @return the DatEncerramento
     */
    public String getDatEncerramento() {
        return DatEncerramento;
    }

    /**
     * @param DatEncerramento the DatEncerramento to set
     */
    public void setDatEncerramento(String DatEncerramento) {
        this.DatEncerramento = DatEncerramento;
    }

    /**
     * @return the DatInicio
     */
    public String getDatInicio() {
        return DatInicio;
    }

    /**
     * @param DatInicio the DatInicio to set
     */
    public void setDatInicio(String DatInicio) {
        this.DatInicio = DatInicio;
    }

    /**
     * @return the Cargoraria
     */
    public String getCargoraria() {
        return Cargoraria;
    }

    /**
     * @param Cargoraria the Cargoraria to set
     */
    public void setCargoraria(String Cargoraria) {
        this.Cargoraria = Cargoraria;
    }
}
