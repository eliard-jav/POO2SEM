/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pessoa;

/**
 *
 * @author LABORATORIO 01
 */
public class Funcionario extends Pessoa{
  private String Departamento;
  private double Salario;
  private String Indentificador;

    /**
     * @return the Departamento
     */
    public String getDepartamento() {
        return Departamento;
    }

    /**
     * @param Departamento the Departamento to set
     */
    public void setDepartamento(String Departamento) {
        this.Departamento = Departamento;
    }

    /**
     * @return the Salario
     */
    public double getSalario() {
        return Salario;
    }

    /**
     * @param Salario the Salario to set
     */
    public void setSalario(double Salario) {
        this.Salario = Salario;
    }

    /**
     * @return the Indentificador
     */
    public String getIndentificador() {
        return Indentificador;
    }

    /**
     * @param Indentificador the Indentificador to set
     */
    public void setIndentificador(String Indentificador) {
        this.Indentificador = Indentificador;
    }

}

