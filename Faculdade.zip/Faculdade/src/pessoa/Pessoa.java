/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pessoa;

/**
 *
 * @author LABORATORIO 01
 */
public class Pessoa {
    private String nome;
    private String Cpf;
    private String DatNacimento;

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the Cpf
     */
    public String getCpf() {
        return Cpf;
    }

    /**
     * @param Cpf the Cpf to set
     */
    public void setCpf(String Cpf) {
        this.Cpf = Cpf;
    }

    /**
     * @return the DatNacimento
     */
    public String getDatNacimento() {
        return DatNacimento;
    }

    /**
     * @param DatNacimento the DatNacimento to set
     */
    public void setDatNacimento(String DatNacimento) {
        this.DatNacimento = DatNacimento;
    }
    
    
    
}
