/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pessoa;

/**
 *
 * @author LABORATORIO 01
 */
public class Monitor extends Aluno {
   private double Salario;
   private String CargHorario;
   private String Rg;

    /**
     * @return the Salario
     */
    public double getSalario() {
        return Salario;
    }

    /**
     * @param Salario the Salario to set
     */
    public void setSalario(double Salario) {
        this.Salario = Salario;
    }

    /**
     * @return the CargHorario
     */
    public String getCargHorario() {
        return CargHorario;
    }

    /**
     * @param CargHorario the CargHorario to set
     */
    public void setCargHorario(String CargHorario) {
        this.CargHorario = CargHorario;
    }

    /**
     * @return the Rg
     */
    public String getRg() {
        return Rg;
    }

    /**
     * @param Rg the Rg to set
     */
    public void setRg(String Rg) {
        this.Rg = Rg;
    }
}
