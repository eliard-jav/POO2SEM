/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import pessoa.Aluno;
import pessoa.Estagiario;
import pessoa.Funcionario;
import pessoa.Monitor;
import pessoa.Pessoa;

/**
 *
 * @author LABORATORIO 01
 */
public class Main {
    public static void main(String[] args) {
        Aluno  a1 = new Aluno();
        Estagiario e1= new Estagiario();
        Funcionario f1=new Funcionario();
        Monitor m1 =new Monitor();
        Pessoa p1=new Pessoa();
        
//Pessoa
         
        p1.setCpf("8942659885-06");
        p1.setDatNacimento("25/01/2000");
        p1.setNome("Paulo");
        
        System.out.println("O cpf é:"+p1.getCpf());
        System.out.println("A Dat de Nacimento é:"+p1.getDatNacimento());
        System.out.println("O nome é:"+p1.getNome());
        
//Funcionario
        f1.setIndentificador("11985");
        f1.setSalario(3000.00);
        f1.setDepartamento("Professor");
        
        System.out.println("O seu Indentificador é"+f1.getIndentificador());
        System.out.println("O Salario é:"+f1.getSalario());
        System.out.println("O seu cargo é:"+f1.getDepartamento());
        
//Estagiario
        e1.setCargoraria("07:00");
        e1.setDatInicio("22/01/2019");
        e1.setDatEncerramento("22/12/2019");
        
        System.out.println("Ele trabalha "+e1.getCargoraria()+" Horas");
        System.out.println("O inicio foi dia "+e1.getDatInicio());
        System.out.println("Vai terminar dia "+e1.getDatEncerramento());
        
//Aluno
        a1.setMatricula("11987");
        a1.setCurso("ADS");
        a1.setSemestre("4ª Semestre");
        
        System.out.println("A matricula dele é"+a1.getMatricula());
        System.out.println("Ele faz o cordo de"+a1.getCurso());
        System.out.println("Ta no "+a1.getSemestre());
        
 //monitor
        m1.setCargHorario("04:00");
        m1.setRg("114638416-6");
        m1.setSalario(400);
        
        System.out.println("Ele trabalha por dia "+m1.getCargHorario());
        System.out.println("O seu rg é:"+m1.getRg());
        System.out.println("Seu salario é "+m1.getSalario());
        
    }
}
