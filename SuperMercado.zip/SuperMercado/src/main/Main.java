/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import produto.Miojo;
import produto.PlacaMae;
import produto.Processador;

/**
 *
 * @author LABORATORIO 01
 */
public class Main {
    public static void main(String[] args) {
        Miojo m1 = new Miojo();
        PlacaMae Pm1= new PlacaMae();
        Processador P1=new Processador();
        
        m1.setNomeProduto("cup noodle");
        Pm1.setNomeProduto("GTX 1050");
        P1.setNomeProduto("Ryzen 5");
        
        System.out.println("O nome do produto é:"+m1.getNomeProduto());
        System.out.println("O nome do produto é:"+Pm1.getNomeProduto());
        System.out.println("O nome do produto é:"+P1.getNomeProduto());
    }
  
}
