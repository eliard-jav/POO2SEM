/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package produto;

/**
 *
 * @author LABORATORIO 01
 */
public class Produto {
    private String NomeProduto;
    private String DataValidade;
    private double preco;

    /**
     * @return the NomeProduto
     */
    public String getNomeProduto() {
        return NomeProduto;
    }

    /**
     * @param NomeProduto the NomeProduto to set
     */
    public void setNomeProduto(String NomeProduto) {
        this.NomeProduto = NomeProduto;
    }

    /**
     * @return the DataValidade
     */
    public String getDataValidade() {
        return DataValidade;
    }

    /**
     * @param DataValidade the DataValidade to set
     */
    public void setDataValidade(String DataValidade) {
        this.DataValidade = DataValidade;
    }

    /**
     * @return the preco
     */
    public double getPreco() {
        return preco;
    }

    /**
     * @param preco the preco to set
     */
    public void setPreco(double preco) {
        this.preco = preco;
    }
}
