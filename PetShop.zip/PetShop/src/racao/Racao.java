/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package racao;

/**
 *
 * @author elliard
 */
public class Racao {
    public String marca;
    public String Tipo;
    public double preco;
    
    
    public Racao(String marca,double preco){
        this.marca=marca;
        this.preco=preco;
    }
}
