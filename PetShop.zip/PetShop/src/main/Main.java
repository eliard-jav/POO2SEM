/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import cachorro.Cachorro;
import funcionario.Funcionario;
import gato.Gato;
import racao.Racao;

/**
 *
 * @author LABORATORIO 01
 */
public class Main {
    public static void main(String[] args) {
        Cachorro dog = new Cachorro( 500, "Rusk");
        System.out.println(dog.raça);
        System.out.println(dog.preço);
        
        Gato cat = new Gato( 5 , "Sphynx");
        System.out.println(cat.raca);
        System.out.println(cat.peso);
        
        Funcionario F1= new Funcionario(1250,"manha");
        System.out.println("O funcionario trbalha pela "+F1.horario);
        System.out.println("O funcionario ganha "+F1.salario);
          
        Racao r1=new Racao("pedigri",20);
        System.out.println("A marca da ração é "+r1.marca);
        System.out.println("O preço da ração é "+r1.preco);
    }
}
