/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package funcionario;


public class Funcionario {
     public String nome;
     public double salario;
     public String horario;
     
     public Funcionario(double salario, String horario){
         this.salario=salario;
         this.horario=horario;
     }
    
    
}
