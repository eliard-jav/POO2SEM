/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gato;

/**
 *
 * @author LABORATORIO 01
 */
public class Gato {
  
  public String raca;
  public double peso;
  public double preço;
  
  public Gato (double peso, String raca){
      this.peso=peso;
      this.raca=raca;
}
}