/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cachorro;


public class Cachorro {
  public String raça;
  public double tamanho;
  public double preço;
  
  public Cachorro(double preço, String raça){
      this.preço=preço;
      this.raça=raça;
  }
  
}
