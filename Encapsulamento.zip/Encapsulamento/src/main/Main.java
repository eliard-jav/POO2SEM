/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import pacote.AlunoPacote;
import privado.AlunoPrivado;
import publico.AlunoPublico;
import protegido.AlunoProtegido;
/**
 *
 * @author LABORATORIO 01
 */
public class Main {
    
    public static void main(String[] args) {
        AlunoPacote aluno1=new AlunoPacote();//Pacote e Classe
        AlunoPrivado aluno2=new AlunoPrivado();//So a classe
        AlunoProtegido aluno3=new AlunoProtegido();//pacote,classe e sunClasse
        AlunoPublico aluno4=new AlunoPublico();//Todos os locais
        
        aluno1.setNome("joão");
        aluno2.setNome("joão");
        aluno3.setNome("joão");
        aluno4.nome="joão";
        
        System.out.println("Aluno Pacote "+aluno1.getNome());
        System.out.println("Aluno Privado "+aluno2.getNome());
        System.out.println("Aluno Protegido "+aluno3.getNome());
        System.out.println("Aluno Publico "+aluno4.nome);
    }
}
