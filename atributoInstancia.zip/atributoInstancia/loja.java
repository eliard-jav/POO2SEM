/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atributoInstancia;

/**
 *
 * @author elliard
 */
public class loja {
   public static String produto;
   public static String tipoproduto;
   public static String preco;
   public static String quantidade;
   public static String validade;
}
