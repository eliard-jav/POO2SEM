/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atributoInstancia;

/**
 *
 * @author elliard
 */
public class aluno {
    public static String nacionalidade; 
    public static String instituicao;
    public static String serie;
    public static String diciplina;
    public static String sala;     
}
