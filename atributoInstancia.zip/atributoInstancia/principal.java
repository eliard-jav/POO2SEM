/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atributoInstancia;

/**
 *
 * @author elliard
 */
public class principal {
    public static void main(String[] args) {
        //classe Instancia aluno
        aluno al =new aluno();
        
        al.nacionalidade="Brasileiro";
        al.instituicao="Fvs";
        
        System.out.println("A nacionalidade do aluno é "+al.nacionalidade);
        System.out.println("O aluno estuda na "+al.instituicao);
        //classe Instancia funcionario
        funcionario fun =new funcionario();
        
        fun.empresa="Google";
        fun.cargo="programador";
        
        System.out.println("O funcionario trabalha na "+fun.empresa);
        System.out.println("O cargo dele é "+fun.cargo);
        
        
        
        concessionaria ve =new concessionaria();
        
        ve.tipo="esportivo";
        ve.marca="tesla";
        
        System.out.println("O carro é da marca "+ve.marca);
        System.out.println("e ele é "+ve.tipo);
        
        loja pro =new loja();
        
        pro.preco="R$15,00";
        pro.tipoproduto="Produto de limpeza";
        
        System.out.println("O produto é do tipo:"+pro.tipoproduto);
        System.out.println("O preço dele é:"+pro.preco);
        
        computador com =new computador();
        
        com.marcaPlacadvideo="gforce";
        com.marcaProcessador="Intel";
        
        System.out.println("A marca do preocessador é:"+com.marcaProcessador);
        System.out.println("E a marca da placa de video é:"+com.marcaPlacadvideo);
    }
}
