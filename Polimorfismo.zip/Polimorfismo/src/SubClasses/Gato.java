/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SubClasses;

import exercicio.Animal;

/**
 *
 * @author Eliard
 */
public class Gato extends Animal{
     //Sbrecarca
    public void Cadastrar(String raca){
        System.out.println("Gato:"+raca + "Castrado");   
    } 
    
     public void Excluir(String raca){
        System.out.println("Gato:"+raca+" Excluido");
    }
      //Sbrescrita
    @Override
     public void Cadastrar(){
        System.out.println("Gato Castrado");   
    }  
     @Override
     public void Excluir(){
        System.out.println("Gato Excluido");
    }
}
