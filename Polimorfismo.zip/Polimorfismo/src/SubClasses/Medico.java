/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SubClasses;

import exercicio.Funcionario;

/**
 *
 * @author Eliard
 */
public class Medico extends Funcionario {
     @Override
     public void Cadastrar(){
        System.out.println("Funcionario Castrado");   
    } 
    
     @Override
    public void Excluir(){
        System.out.println("Funcionario Excluido");
    }
    
        public void Cadastrar(String ID){
        System.out.println("Funcionario:"+ID+" Castrado");   
    } 
    
        public void Excluir(String ID){
        System.out.println("Funcionario"+ID+" Excluido");
    }
}
