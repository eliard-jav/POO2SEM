/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SubClasses;

import exercicio.Pessoa;

/**
 *
 * @author Eliard
 */
public class Usuario extends Pessoa {
       @Override
     public void Cadastrar(){
        System.out.println("Usuario Castrado");   
    } 
    
     @Override
    public void Excluir(){
        System.out.println("Usuario Excluido");
    }
    
    
     public void Cadastrar(String nome){
        System.out.println("Usuario:"+nome+" Castrado");   
    } 
      public void Excluir (String nome){
        System.out.println("Usuario:"+nome+" Castrado");   
    } 
}
