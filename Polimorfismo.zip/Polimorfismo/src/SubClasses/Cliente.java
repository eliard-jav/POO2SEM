/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SubClasses;

import exercicio.Pessoa;

/**
 *
 * @author Eliard
 */
public class Cliente extends Pessoa {
      @Override
     public void Cadastrar(){
        System.out.println("Cliente Castrado");   
    } 
    
     @Override
    public void Excluir(){
        System.out.println("Cliente Excluido");
    } 
    
     public void Cadastrar(String nome){
        System.out.println("Cliente:"+nome+" Castrado");   
    } 
      public void Excluir (String nome){
        System.out.println("Cliente:"+nome+" Castrado");   
    } 
}
