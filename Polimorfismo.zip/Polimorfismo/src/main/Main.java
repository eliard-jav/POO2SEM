/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import SubClasses.Aluno;
import SubClasses.Atendente;
import SubClasses.Cachorro;
import SubClasses.Cliente;
import SubClasses.Cobra;
import SubClasses.Enfermeira;
import SubClasses.Gato;
import SubClasses.Medico;
import SubClasses.Usuario;


/**
 *
 * @author Eliard
 */
public class Main {
    public static void main(String[] args) {
       //ANIMAL
        Cachorro Ca1=new Cachorro();
         Cobra Co1= new Cobra();
         Gato G1= new Gato();
         
         Ca1.Cadastrar();
         Ca1.Excluir("Bulldog");
         
         Co1.Cadastrar("Anaconda");
         Co1.Excluir();
         
         G1.Cadastrar();
         G1.Excluir();
      
//FUNCIONARIO
        Medico M1= new Medico();
        Enfermeira E1=new Enfermeira();
        Atendente A1=new Atendente();
        
        M1.Cadastrar("213614");
        M1.Cadastrar();
        
        E1.Excluir("85941");
        E1.Excluir();
        
        A1.Cadastrar("55112");
        A1.Excluir("64343");
        
        //PESSOA
        Aluno Al1= new Aluno();
        Usuario U1= new Usuario();
        Cliente C1= new Cliente();
        
        Al1.Cadastrar("PEDRO");
        Al1.Cadastrar();
        
        U1.Excluir("João");
        U1.Excluir();
        
        C1.Cadastrar("Fernanda");
        C1.Excluir("Claudia");
    }
}
