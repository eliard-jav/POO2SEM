/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atributoClasse;

/**
 *
 * @author elliard
 */
public class carro {
    public String marca;
    public String cor;
    public String modelo;
    public String datFab;
    public String velocidadeMax;
            
            }
