/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atributoClasse;

/**
 *
 * @author elliard
 */
public class pessoa {
    public String nome;
    public String cpf;
    public String sexo;
    public String idade;
    public String cep;
}
