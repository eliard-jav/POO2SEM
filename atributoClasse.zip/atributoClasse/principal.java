/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atributoClasse;

/**
 *
 * @author elliard
 */
public class principal {
     //classe principal da pessoa;
    public static void main(String[] args) {
        pessoa p1=new pessoa();
        
        p1.nome="José";
        p1.idade="20";
        
        
        System.out.println("O nome da pessoa é "+p1.nome);
        System.out.println("A idade dessa pessoa é "+p1.idade);
    
        //classe principal do carro;
        carro cr1=new carro();
        
        cr1.marca="FIAT";
        cr1.cor="azul";
         
        System.out.println("A marca do carro é "+cr1.marca);
        System.out.println("A cor do carro  é "+cr1.cor);
        
        //classe principal do funcionario
        funcionario fun=new funcionario();
        
        fun.departamento="financeiro";
        fun.salario="R$ 2000 ";
        
        System.out.println("O funcionario pertence ao departamento:"+fun.departamento);
        System.out.println("O salario do funcionario é de:"+fun.salario);
        
        //classe principal do jogo
        jogo jg1=new jogo();
        
        jg1.nome="need for speed";
        jg1.desenvolvedora="EA";
        
        System.out.println("O nome do jogo é "+jg1.nome);
        System.out.println("O jogo foi feito pela "+jg1.desenvolvedora);
        
         //classe principal d livro
         livro lv=new livro();
         
         
         lv.genero="Acão";
         lv.tipo="Mangá";
                
         System.out.println("Esse livro é de:"+lv.genero);
         System.out.println("O livro é estilo:"+lv.tipo);
    }


        
    
}
