/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package funcionario;

/**
 *
 * @author LABORATORIO 01
 */
public class Secretaria extends Funcionario{
    
    @Override 
    public void bonificacao(){
        setBonificacao(getSalario()*0.05);
    }
}
