/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import funcionario.Funcionario;
import funcionario.Gerente;
import funcionario.Secretaria;
import funcionario.ServicoGerais;

/**
 *
 * @author LABORATORIO 01
 */
public class Main {
    
    public static void calcularBonificacao(Funcionario f){
        f.bonificacao();
        if(f instanceof Gerente){
           System.out.println("Gerente:"+(f.getSalario()+f.getBonificacao())); 
        }else if (f instanceof Secretaria){
           System.out.println("Secretaria:"+(f.getSalario()+f.getBonificacao())); 
        }else{System.out.println("Serv. Gerais:"+(f.getSalario()+f.getBonificacao()));
            
        }
    } 
    public static void main(String[] args) {
        Gerente g = new Gerente();
        Secretaria s= new Secretaria();
        ServicoGerais sg = new ServicoGerais();
        
        g.setSalario(1000);
        s.setSalario(1000);
        sg.setSalario(1000);
        
        calcularBonificacao(s);
        calcularBonificacao(g);
        calcularBonificacao(sg);
    }
}
