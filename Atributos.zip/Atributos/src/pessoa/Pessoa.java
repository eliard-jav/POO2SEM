
package pessoa;


public class Pessoa {
public String nome;
public String cpf;
public static String nacionalidade ;
public String dataNacimento;
public String etnia;

public void andar(){
    System.out.println("Andando!");
}
}
