/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import aluno.Aluno;
import pessoa.Pessoa;

/**
 *
 * @author LABORATORIO 01
 */
public class Main {
    public static void main(String[] args) {
      Aluno a1=new Aluno();
      Aluno a2=new Aluno();
      
      a1.nome="Maria";
      a2.nome="José";
      
      a1.matricula="0223";
      a2.matricula="1223";
      
      a1.instituicao="Fvs";
      a2.instituicao="Fvs";
       
      a1.nacionalidade="brasileiro";
      a2.nacionalidade="brasileiro";
      
      System.out.println("O nome do aluno1 é:"+a1.nome);
      System.out.println("O nome do aluno2 é:"+a2.nome);
      System.out.println("A matricula do aluno1 é:"+a1.matricula);
      System.out.println("A matricula do aluno2 é:"+a2.matricula);
      System.out.println("A instituição do aluno1 é:"+a1.instituicao);
      System.out.println("A instituição do aluno2 é:"+a2.instituicao);
      System.out.println("A instituição do aluno1 é:"+a1.nacionalidade);
      System.out.println("A instituição do aluno2 é:"+a2.nacionalidade);
      
      
              
    } 
}
